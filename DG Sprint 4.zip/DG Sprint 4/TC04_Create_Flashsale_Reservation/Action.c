Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC04_Create_Flashsale_Reservation");
	
	web_custom_request("TC04_Create_Flashsale_Reservation",
    "URL=https://apist.duniagames.co.id/api/product/v1/reservation/promo",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC04_Create_Flashsale_Reservation", LR_AUTO);
	
	return 0;
}