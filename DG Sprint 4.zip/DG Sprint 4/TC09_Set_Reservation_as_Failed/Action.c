Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC09_Set_Reservation_as_Failed");
	
	web_custom_request("TC09_Set_Reservation_as_Failed",
    "URL=https://apist.duniagames.co.id/api/product/v1/reservation/promo/set-failed/{itemId}",
    "Method=PUT",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC09_Set_Reservation_as_Failed", LR_AUTO);
	
	return 0;
}

