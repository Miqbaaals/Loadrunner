Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC08_Set_Reservation_as_Success");
	
	web_custom_request("TC08_Set_Reservation_as_Success",
    "URL=https://apist.duniagames.co.id/api/product/v1/reservation/promo/set-success/{itemId}",
    "Method=PUT",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC08_Set_Reservation_as_Success", LR_AUTO);
	
	return 0;
}