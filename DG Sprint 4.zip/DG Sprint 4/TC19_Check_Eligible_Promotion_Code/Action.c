Action()
{
	web_add_header("Content-Type", "application/json");
	web_add_header("x-api-key","14d8e71cd79d42d2ffed47a16dcf361a");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC13_Check_Eligible_Promotion_Code");
	
	web_custom_request("TC13_Check_Eligible_Promotion_Code",
    "URL=https://10.54.16.151:8141/v1/check-eligible-promotion-code/",
    "Method=POST",
    "Body={\"phoneNumber\" : \"681373100105\",\"channel\" : \"web\",\"promotionCode\" : \"DG-CUMAXMAX\",\"itemId\" : 2}",
    
    LAST);
	
	lr_end_transaction("TC13_Check_Eligible_Promotion_Code", LR_AUTO);
	
	return 0;
}

 