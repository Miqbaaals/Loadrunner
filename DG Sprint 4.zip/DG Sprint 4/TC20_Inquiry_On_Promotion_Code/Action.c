Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC20_Inquiry_On_Promotion_Code");
	
	web_custom_request("TC20_Inquiry_On_Promotion_Code",
    "URL=https://apist.duniagames.co.id/api/transaction/v1/top-up/inquiry/store-va",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC20_Inquiry_On_Promotion_Code", LR_AUTO);
	
	return 0;
}

