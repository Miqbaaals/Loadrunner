Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC14_Transaction_Settlement");
	
	web_custom_request("TC14_Transaction_Settlement",
    "URL=https://apist.duniagames.co.id/api/transaction/v1/top-up/transaction/store",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC14_Transaction_Settlement", LR_AUTO);
	
	return 0;
}