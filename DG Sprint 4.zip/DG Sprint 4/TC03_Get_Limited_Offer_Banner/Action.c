Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC03_Get_Limited_Offer_Banner");
	
	web_custom_request("TC03_Get_Limited_Offer_Banner",
    "URL=https://10.54.16.151:8141/v1/limited_offer",
    "Method=GET",
    
    LAST);
	
	lr_end_transaction("TC03_Get_Limited_Offer_Banner", LR_AUTO);
	
	return 0;
}

