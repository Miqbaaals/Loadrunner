Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC05_Check_Quota_Bulk");
	
	web_custom_request("TC05_Check_Quota_Bulk",
    "URL=https://10.54.16.151:8141/v1/limited_offer/check/bulk",
    "Method=POST",
    "Body={\n    \"id\":[237,303]\n}",
    
    LAST);
	
	lr_end_transaction("TC05_Check_Quota_Bulk", LR_AUTO);
	
	return 0;
}