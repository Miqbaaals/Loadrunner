Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC12_Transaction_Inquiry");
	
	web_custom_request("TC12_Transaction_Inquiry",
    "URL=https://apist.duniagames.co.id/api/transaction/v1/top-up/inquiry/store",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC12_Transaction_Inquiry", LR_AUTO);
	
	return 0;
}