Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC02_Get_Promotion_Card");
	
	web_custom_request("TC02_Get_Promotion_Card",
    "URL=https://10.54.16.151:8141/v1/promotion_card",
    "Method=GET",
    
    LAST);
	
	lr_end_transaction("TC02_Get_Promotion_Card", LR_AUTO);
	
	return 0;
}

