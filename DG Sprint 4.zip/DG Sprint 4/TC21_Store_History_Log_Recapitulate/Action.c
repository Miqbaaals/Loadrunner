Action()
{
	web_add_header("Content-Type", "application/json");
	web_add_header("x-api-key","14d8e71cd79d42d2ffed47a16dcf361a");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC14_Store_History_Log_Recapitulate");
	
	web_custom_request("TC14_Store_History_Log_Recapitulate",
    "URL=https://10.54.16.151:8141/v1/store-log-promotion-code",
    "Method=POST",
    "Body={\n    \"transactionCode\":\"2020113017199430\",\n    \"total\":18500,\n    \"productId\":1,\n    \"itemId\":2,\n    \"codePayment\":1,\n    \"purchaseDate\":\"2020-12-01\",\n    \"phoneNumber\":\"62811890902\"\n}",
    
    LAST);
	
	lr_end_transaction("TC14_Store_History_Log_Recapitulate", LR_AUTO);
	
	return 0;
}

