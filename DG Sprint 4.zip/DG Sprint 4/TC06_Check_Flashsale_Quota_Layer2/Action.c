Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC06_Check_Flashsale_Quota_Layer2");
	
	web_custom_request("TC06_Check_Flashsale_Quota_Layer2",
    "URL=https://apist.duniagames.co.id/api/product/v1/limited_offer/check-settlement/{itemId}/{inquiryId}/{msisdn}",
    "Method=GET",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC06_Check_Flashsale_Quota_Layer2", LR_AUTO);
	
	return 0;
}