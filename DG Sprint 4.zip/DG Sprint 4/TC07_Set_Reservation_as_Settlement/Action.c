Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC07_Set_Reservation_as_Settlement");
	
	web_custom_request("TC07_Set_Reservation_as_Settlement",
    "URL=https://apist.duniagames.co.id/api/product/v1/reservation/promo/set-settlement",
    "Method=PUT",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC07_Set_Reservation_as_Settlement", LR_AUTO);
	
	return 0;
}