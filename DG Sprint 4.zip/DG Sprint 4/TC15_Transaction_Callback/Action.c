Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC09_Transaction_Callback");
	
	web_custom_request("TC09_Transaction_Callback",
    "URL=https://10.54.16.147:8110/v1/top-up/transaction/nbp-callback",
    "Method=POST",
    "Body={\"trx_id\":\"20210217103542146065\",\"message_type\":\"MT\",\"msisdn\":\"62811890902\",\"message\":\"Pulsa Anda telah terpotong untuk membeli diamond senilai Rp 5.000 (inc. ppn). (CS :1500853)\",\"status\":\"success\"}",
    
    LAST);
	
	lr_end_transaction("TC09_Transaction_Callback", LR_AUTO);
	
	return 0;
}