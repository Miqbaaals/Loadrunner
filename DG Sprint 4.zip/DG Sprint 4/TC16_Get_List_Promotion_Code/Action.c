Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC10_Get_List_Promotion_Code");
	
	web_custom_request("TC10_Get_List_Promotion_Code",
    "URL=https://10.54.16.151:8141/v1/promotion-code?Include=detailContentPromotion,detailProductItemEligible",
    "Method=GET",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC10_Get_List_Promotion_Code", LR_AUTO);
	
	return 0;
}