Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC07_inquiry");
	
	web_custom_request("TC07_inquiry",
    "URL=https://10.54.16.147:8110/v1/top-up/inquiry/store-va",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC07_inquiry", LR_AUTO);
	
	return 0;
}