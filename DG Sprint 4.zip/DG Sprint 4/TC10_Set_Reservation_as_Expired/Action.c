Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC10_Set_Reservation_as_Expired");
	
	web_custom_request("TC10_Set_Reservation_as_Expired",
    "URL=https://apist.duniagames.co.id/api/product/v1/reservation/promo/set-expired/{itemId}",
    "Method=PUT",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC10_Set_Reservation_as_Expired", LR_AUTO);
	
	return 0;
}

