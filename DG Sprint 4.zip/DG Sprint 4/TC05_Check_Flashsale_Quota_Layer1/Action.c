Action()
{
	web_add_header("Content-Type", "application/json");
	web_add_header("x-api-key","14d8e71cd79d42d2ffed47a16dcf361a");
	
	web_reg_find("text=Active",LAST);
	
	lr_start_transaction("TC04_Check_Flashsale_Quota_Layer1");
	
	web_custom_request("TC04_Check_Flashsale_Quota_Layer1",
    "URL=https://10.54.16.151:8141/v1/limited_offer/check/237",
    "Method=GET",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC04_Check_Flashsale_Quota_Layer1", LR_AUTO);
	
	return 0;
}

