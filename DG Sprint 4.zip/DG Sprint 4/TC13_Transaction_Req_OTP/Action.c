Action()
{
	web_add_header("Content-Type", "application/json");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC06_Transaction_Req_OTP");
	
	web_custom_request("TC06_Transaction_Req_OTP",
    "URL=https://10.54.16.147:8110/v1/top-up/transaction/req-otp-va",
    "Method=POST",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC06_Transaction_Req_OTP", LR_AUTO);
	
	return 0;
}