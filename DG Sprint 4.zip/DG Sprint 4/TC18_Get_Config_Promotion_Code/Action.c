Action()
{
	web_add_header("Content-Type", "application/json");
	web_add_header("x-api-key","14d8e71cd79d42d2ffed47a16dcf361a");
	
	web_reg_find("text=success",LAST);
	
	lr_start_transaction("TC12_Get_Config_Promotion_Code");
	
	web_custom_request("TC12_Get_Config_Promotion_Code",
    "URL=https://10.54.16.151:8141/v1/get-config-promotion-code/DG-CUMAXMAX",
    "Method=GET",
    //"Body=",
    
    LAST);
	
	lr_end_transaction("TC12_Get_Config_Promotion_Code", LR_AUTO);
	
	return 0;
}